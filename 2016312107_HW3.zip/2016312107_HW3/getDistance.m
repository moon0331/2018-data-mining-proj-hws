function norm=getDistance(x, y) 
    norm=vecnorm(x-y);
end
